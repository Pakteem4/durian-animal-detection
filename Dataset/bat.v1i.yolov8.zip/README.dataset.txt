# bat > 2024-05-22 3:59pm
https://universe.roboflow.com/ahmeddod/bat-899or

Provided by a Roboflow user
License: CC BY 4.0

