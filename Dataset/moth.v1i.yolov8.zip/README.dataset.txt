# moth > 2024-08-23 1:28pm
https://universe.roboflow.com/pj1-buarq/moth-oft50

Provided by a Roboflow user
License: CC BY 4.0

